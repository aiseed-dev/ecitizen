series { 
 file= 'm03.dat'
 start =1994.1
 span =(1994.1,2011.2)
 modelspan =(1994.1,2011.2)
 period=4
 decimals =3
 precision =3}
transform { function = log }
arima { model = ( 0 1 1 )( 2 1 0 ) }
forecast { maxlead = 8
           maxback = 20 }
regression {
 user = (vat97)
 file = 'vat97.dat'
 format = 'datevalue' }
estimate { maxiter = 20000 }
x11{ savelog = q
 appendfcst = yes
 save = ( d11 d16 ) }
