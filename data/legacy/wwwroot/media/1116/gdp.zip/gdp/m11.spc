series { 
 file= 'm11.dat'
 start =1980.1
 span =(1980.1,2011.2)
 modelspan =(1980.1,2011.2)
 period=4
 decimals =3
 precision =3}
transform { function = auto }
arima { model = ( 1 1 2 )( 0 1 1 ) }
forecast { maxlead = 8 }
regression {
 variables = ( AO2007.4 )}
estimate { maxiter = 20000 }
x11{ savelog = q
 appendfcst = yes
 save = ( d11 d16 ) }
