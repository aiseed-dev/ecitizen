series{
	file= 'iip0.dat'
	start=2004.1
	span=(2004.1,2010.12)
    decimals=1
}
transform  { function = log }
arima { model=(2 1 0)(0 1 1)}
regression { variables=(td1nolpyear lpyear)
       save=( td hol )
       user=(jap-hol)
       usertype=holiday
       start=2004.1
       file="holiday.dat"
}
forecast{maxlead=12}
estimate { save = ( mdl)
		maxiter = 500 }
x11    { print = (none + d10 +d11 +d16)
         save  = (d10 d11 d16)
	    seasonalma=x11default
}
